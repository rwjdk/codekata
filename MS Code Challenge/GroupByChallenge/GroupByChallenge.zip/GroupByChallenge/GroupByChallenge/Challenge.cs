﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupByChallenge
{
    public class Challenge
    {
        /* Group By Challenge
         * 
         * In this challenge, you will receive an array of objects (POCOs) as the input for your method.
         * 
         * You must group the objects by their types and return a dictionary with the type as the key and the number of occurrences of each type as the value.
         * 
         * Hint: LINQ is your friend!
         * 
         * Good luck!
         */

        public Dictionary<Type, int> Execute(object[] input)
        {
            return null;
        }
    }
}
